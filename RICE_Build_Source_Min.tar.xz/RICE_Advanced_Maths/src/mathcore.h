#ifndef RICE_MATHCORE_H
#define RICE_MATHCORE_H

#include <stddef.h>

#define RICE_POLY_MAX_DEGREE 8

typedef struct {
    double c[RICE_POLY_MAX_DEGREE + 1]; /* c[i] is the coefficient of x^i */
    int degree;
} RicePolynomial;

/* Evaluate a numeric expression. sin/cos/tan arguments are in degrees. */
int rice_eval_expression(const char *expression, double *answer,
                         char *error, size_t error_size);

/* Parse, simplify and expand a univariate polynomial expression in x.
   Supports +, -, *, / by a non-zero constant, parentheses, implicit
   multiplication (2x and (x+1)(x+2)), and integer powers 0..8. */
int rice_parse_polynomial(const char *expression, RicePolynomial *out,
                          char *error, size_t error_size);

void rice_polynomial_derivative(const RicePolynomial *p, RicePolynomial *out);
double rice_polynomial_evaluate(const RicePolynomial *p, double x);
int rice_polynomial_format(const RicePolynomial *p, char *buffer, size_t size);

#endif
