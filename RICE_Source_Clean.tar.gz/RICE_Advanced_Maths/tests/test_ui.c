#include <gint/keycodes.h>
#include "fake_gint.h"
#include <stdio.h>

int rice_app_main(void);

int main(void)
{
    fake_gint_reset();
    /* Main menu -> expression calculator -> sin(30)+sqrt(9) -> close -> exit. */
    fake_gint_push_key(KEY_DOWN, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_SIN, 0);
    fake_gint_push_key(KEY_3, 0);
    fake_gint_push_key(KEY_0, 0);
    fake_gint_push_key(KEY_RIGHTP, 0);
    fake_gint_push_key(KEY_ADD, 0);
    fake_gint_push_key(KEY_SQUARE, 1);
    fake_gint_push_key(KEY_9, 0);
    fake_gint_push_key(KEY_RIGHTP, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_EXIT, 0);
    (void)rice_app_main();
    if(!fake_gint_text_contains("= 3.5")) {
        puts("FAIL: UI did not display expected trig/square-root expression result");
        return 1;
    }
    /* Select the polynomial expansion menu item and expand a bracket product. */
    fake_gint_reset();
    for(int i = 0; i < 12; i++) fake_gint_push_key(KEY_DOWN, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_LEFTP, 0);
    fake_gint_push_key(KEY_XOT, 0);
    fake_gint_push_key(KEY_ADD, 0);
    fake_gint_push_key(KEY_2, 0);
    fake_gint_push_key(KEY_RIGHTP, 0);
    fake_gint_push_key(KEY_MUL, 0);
    fake_gint_push_key(KEY_LEFTP, 0);
    fake_gint_push_key(KEY_XOT, 0);
    fake_gint_push_key(KEY_ADD, 0);
    fake_gint_push_key(KEY_3, 0);
    fake_gint_push_key(KEY_RIGHTP, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_EXIT, 0);
    (void)rice_app_main();
    if(!fake_gint_text_contains("x^2 + 5x + 6")) {
        puts("FAIL: UI did not display expanded polynomial");
        return 1;
    }
    /* Linear inequality: -2x + 3 < 7 becomes x > -2. */
    fake_gint_reset();
    for(int i = 0; i < 6; i++) fake_gint_push_key(KEY_DOWN, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_NEG, 0); fake_gint_push_key(KEY_2, 0); fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_3, 0); fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_7, 0); fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_EXIT, 0);
    (void)rice_app_main();
    if(!fake_gint_text_contains("x > -2")) {
        puts("FAIL: UI did not reverse inequality after division by a negative number");
        return 1;
    }

    /* Degenerate simultaneous system: 0=1 and 0=0 has no solution. */
    fake_gint_reset();
    for(int i = 0; i < 7; i++) fake_gint_push_key(KEY_DOWN, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_0, 0); fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_0, 0); fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_1, 0); fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_0, 0); fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_0, 0); fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_0, 0); fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_EXIT, 0);
    (void)rice_app_main();
    if(!fake_gint_text_contains("No solution")) {
        puts("FAIL: UI mishandled degenerate simultaneous equations");
        return 1;
    }

    /* Stable quadratic roots: x^2 - 100000000x + 1 = 0. */
    fake_gint_reset();
    for(int i = 0; i < 8; i++) fake_gint_push_key(KEY_DOWN, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_1, 0); fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_NEG, 0); fake_gint_push_key(KEY_1, 0);
    for(int i = 0; i < 8; i++) fake_gint_push_key(KEY_0, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_1, 0); fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_EXIT, 0);
    (void)rice_app_main();
    if(!fake_gint_text_contains("x1 = 1e-08")) {
        puts("FAIL: quadratic solver did not preserve the small root");
        return 1;
    }

    /* Quadratic factor form: x^2 + 5x + 6 = (x+3)(x+2). */
    fake_gint_reset();
    for(int i = 0; i < 9; i++) fake_gint_push_key(KEY_DOWN, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_XOT, 0);
    fake_gint_push_key(KEY_POWER, 0); fake_gint_push_key(KEY_2, 0);
    fake_gint_push_key(KEY_ADD, 0); fake_gint_push_key(KEY_5, 0); fake_gint_push_key(KEY_XOT, 0);
    fake_gint_push_key(KEY_ADD, 0); fake_gint_push_key(KEY_6, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_EXE, 0);
    fake_gint_push_key(KEY_EXIT, 0);
    (void)rice_app_main();
    if(!fake_gint_text_contains("(x + 3)(x + 2)")) {
        puts("FAIL: UI did not show the expected quadratic factor form");
        return 1;
    }

    puts("RICE UI smoke tests: passed");
    return 0;
}
